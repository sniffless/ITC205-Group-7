package datamanagement;
public class StudentMap extends java.util.HashMap<Integer, IStudent> {}
