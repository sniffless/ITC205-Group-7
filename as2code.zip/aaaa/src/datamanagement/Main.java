package datamanagement;

public class Main {
    public static void main(String[] p) {new cgCTL().execute();}    }
