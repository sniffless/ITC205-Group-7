package datamanagement;

/**
 * @author jtulip
 */

public interface IStudentLister {

    public void clearStudents();
    public void addStudent(IStudent student);
}
